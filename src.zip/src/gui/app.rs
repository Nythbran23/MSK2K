// src/gui/app.rs
use cpal::traits::{DeviceTrait, HostTrait};
use eframe::egui;

use crate::engine::{EngineHandle, SlotParity, SlotPeriod, UiCmd, UiEvent};

pub fn run_gui() -> anyhow::Result<()> {
    let options = eframe::NativeOptions::default();
    let engine = crate::engine::start_engine();

    if let Err(e) = eframe::run_native(
        "MSK2K",
        options,
        Box::new(|_cc| Box::new(Msk2kEguiApp::new(engine))),
    ) {
        eprintln!("eframe error: {e}");
    }

    Ok(())
}

struct Msk2kEguiApp {
    engine: EngineHandle,

    // Station
    my_call: String,
    their_call: String,  // ✅ NEW: Remote callsign field

    // Slot controls
    slot_parity: SlotParity,
    slot_period: SlotPeriod,

    // Audio devices
    in_devs: Vec<String>,
    out_devs: Vec<String>,
    sel_in: Option<String>,
    sel_out: Option<String>,

    // Logs
    rx_log: Vec<String>,
    tx_log: Vec<String>,
    info_log: Vec<String>,
    cq_log: Vec<String>,  // NEW: Separate log for CQ calls only
    last_snr: f32,
}

impl Msk2kEguiApp {
    fn new(engine: EngineHandle) -> Self {
        let (in_devs, out_devs) = enumerate_audio_devices();

        let app = Self {
            engine,
            my_call: "GW4WND".to_string(),  // Default callsign (will be loaded from storage)
            their_call: String::new(),       // ✅ NEW: Empty initially

            slot_parity: SlotParity::Odd,
            slot_period: SlotPeriod::S15,

            in_devs,
            out_devs,
            sel_in: None,   // Will be loaded from storage
            sel_out: None,  // Will be loaded from storage

            rx_log: Vec::new(),
            tx_log: Vec::new(),
            info_log: Vec::new(),
            cq_log: Vec::new(),  // NEW: Empty CQ log
            last_snr: 0.0,
        };
        
        // ✅ Send initial LISTEN command to set my_call in runtime
        let _ = app.engine.cmds.send(UiCmd::Listen {
            my_call: app.my_call.clone(),
            their_call: String::new(),
            auto_slots: true,
        });
        log::info!("🚀 Sent initial LISTEN command with my_call='{}'", app.my_call);
        
        app
    }
    
    // ✅ NEW: Load persistent settings from egui storage
    fn load_settings(&mut self, ctx: &egui::Context) {
        ctx.data_mut(|d| {
            if let Some(call) = d.get_persisted::<String>(egui::Id::new("my_call")) {
                self.my_call = call;
                log::info!("📂 Loaded my_call: {}", self.my_call);
            }
            if let Some(dev) = d.get_persisted::<String>(egui::Id::new("sel_in")) {
                self.sel_in = Some(dev);
                log::info!("📂 Loaded RX device: {:?}", self.sel_in);
            }
            if let Some(dev) = d.get_persisted::<String>(egui::Id::new("sel_out")) {
                self.sel_out = Some(dev);
                log::info!("📂 Loaded TX device: {:?}", self.sel_out);
            }
        });
    }
    
    // ✅ NEW: Save persistent settings to egui storage
    fn save_settings(&self, ctx: &egui::Context) {
        ctx.data_mut(|d| {
            d.insert_persisted(egui::Id::new("my_call"), self.my_call.clone());
            if let Some(ref dev) = self.sel_in {
                d.insert_persisted(egui::Id::new("sel_in"), dev.clone());
            }
            if let Some(ref dev) = self.sel_out {
                d.insert_persisted(egui::Id::new("sel_out"), dev.clone());
            }
        });
    }

    fn drain_events(&mut self) {
        while let Ok(ev) = self.engine.events.try_recv() {
            match ev {
                UiEvent::Info(s) => push_cap(&mut self.info_log, s),
                UiEvent::RxText { text, snr, utc_ms, rx_slot } => {
                    self.last_snr = snr.unwrap_or(self.last_snr);
                    push_cap(&mut self.rx_log, text.clone());
                    
                    // If it's a CQ call, also add to CQ log
                    if text.to_uppercase().contains("CQ") {
                        push_cap(&mut self.cq_log, text);
                    }
                }
                UiEvent::TxText { text } => push_cap(&mut self.tx_log, text),
                UiEvent::State(s) => push_cap(&mut self.info_log, format!("STATE: {s}")),
                UiEvent::TheirCallChanged { callsign } => {
                    // ✅ Auto-populate or clear Remote Call field
                    self.their_call = callsign;
                }
                UiEvent::TxSlotChanged { slot } => {
                    // ✅ Auto-update TX slot dropdown when auto-locked
                    self.slot_parity = slot;
                }
            }
        }
    }

    fn send_apply_audio(&mut self) {
        let _ = self.engine.cmds.send(UiCmd::SetInputDevice(self.sel_in.clone()));
        let _ = self.engine.cmds.send(UiCmd::SetOutputDevice(self.sel_out.clone()));
        let _ = self.engine.cmds.send(UiCmd::SetSlotParity(self.slot_parity));
        let _ = self.engine.cmds.send(UiCmd::SetSlotPeriod(self.slot_period));
        let _ = self.engine.cmds.send(UiCmd::SetAutoQso(true));  // Always auto
        let _ = self.engine.cmds.send(UiCmd::ApplyAudio);
    }
}

impl eframe::App for Msk2kEguiApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        // ✅ Load settings on first frame only
        static mut LOADED: bool = false;
        unsafe {
            if !LOADED {
                self.load_settings(ctx);
                LOADED = true;
            }
        }
        
        self.drain_events();

        egui::TopBottomPanel::top("top").show(ctx, |ui| {
            // ===== Row 1: Callsign =====
            ui.horizontal(|ui| {
                ui.label("My Call:");
                let my_call_edit = ui.text_edit_singleline(&mut self.my_call);
                
                // ✅ Apply callsign immediately when changed
                if my_call_edit.changed() {
                    self.my_call = self.my_call.to_uppercase();
                    log::info!("✅ Callsign changed to: {} (will be applied on next action)", self.my_call);
                    
                    // Save to persistence
                    self.save_settings(ctx);
                }
                
                ui.add_space(20.0);
                
                // ✅ NEW: Remote Call field
                ui.label("Remote Call:");
                let their_call_edit = ui.text_edit_singleline(&mut self.their_call);
                if their_call_edit.changed() {
                    // Auto-uppercase as user types
                    self.their_call = self.their_call.to_uppercase();
                }
                
                ui.add_space(20.0);
                ui.label(format!("SNR: {:.1} dB", self.last_snr));
            });

            ui.separator();

            // ===== Row 2: Audio devices =====
            ui.horizontal(|ui| {
                ui.label("RX In:");
                let rx_combo = egui::ComboBox::from_id_source("rx_in_combo")
                    .selected_text(self.sel_in.clone().unwrap_or_else(|| "(default)".into()))
                    .show_ui(ui, |ui| {
                        let mut changed = false;
                        if ui.selectable_value(&mut self.sel_in, None, "(default)".to_string()).clicked() {
                            changed = true;
                        }
                        for d in &self.in_devs {
                            if ui.selectable_value(&mut self.sel_in, Some(d.clone()), d.clone()).clicked() {
                                changed = true;
                            }
                        }
                        changed
                    });
                
                // ✅ Save when RX device changes
                if rx_combo.inner.unwrap_or(false) {
                    self.save_settings(ctx);
                    log::info!("💾 Saved RX device: {:?}", self.sel_in);
                }

                ui.label("TX Out:");
                let tx_combo = egui::ComboBox::from_id_source("tx_out_combo")
                    .selected_text(self.sel_out.clone().unwrap_or_else(|| "(default)".into()))
                    .show_ui(ui, |ui| {
                        let mut changed = false;
                        if ui.selectable_value(&mut self.sel_out, None, "(default)".to_string()).clicked() {
                            changed = true;
                        }
                        for d in &self.out_devs {
                            if ui.selectable_value(&mut self.sel_out, Some(d.clone()), d.clone()).clicked() {
                                changed = true;
                            }
                        }
                        changed
                    });
                
                // ✅ Save when TX device changes  
                if tx_combo.inner.unwrap_or(false) {
                    self.save_settings(ctx);
                    log::info!("💾 Saved TX device: {:?}", self.sel_out);
                }

                if ui.button("Apply Audio").clicked() {
                    self.send_apply_audio();
                }
            });

            ui.separator();

            // ===== Row 3: Slot timing =====
            ui.horizontal(|ui| {
                ui.label("Slot Period:");
                egui::ComboBox::from_id_source("slot_period")
                    .selected_text(match self.slot_period {
                        SlotPeriod::S15 => "15s",
                        SlotPeriod::S30 => "30s",
                    })
                    .show_ui(ui, |ui| {
                        ui.selectable_value(&mut self.slot_period, SlotPeriod::S15, "15s");
                        ui.selectable_value(&mut self.slot_period, SlotPeriod::S30, "30s");
                    });

                ui.label("TX Slot:");
                egui::ComboBox::from_id_source("slot_parity")
                    .selected_text(match self.slot_parity {
                        SlotParity::Odd => "Odd",
                        SlotParity::Even => "Even",
                    })
                    .show_ui(ui, |ui| {
                        ui.selectable_value(&mut self.slot_parity, SlotParity::Odd, "Odd");
                        ui.selectable_value(&mut self.slot_parity, SlotParity::Even, "Even");
                    });
            });

            ui.separator();

            // ===== Row 4: Main controls =====
            ui.horizontal(|ui| {
                ui.heading("Controls:");
                
                ui.add_space(10.0);
                
                // CQ button - starts calling CQ
                if ui.button("📢 CALL CQ").clicked() {
                    let _ = self.engine.cmds.send(UiCmd::StartCq {
                        my_call: self.my_call.clone(),
                        auto_slots: true,
                    });
                }
                
                ui.add_space(5.0);
                
                // Listen button - back to RX only
                if ui.button("📻 LISTEN").clicked() {
                    let _ = self.engine.cmds.send(UiCmd::Listen {
                        my_call: self.my_call.clone(),
                        their_call: String::new(),
                        auto_slots: true,
                    });
                }
                
                ui.add_space(5.0);
                
                // ✅ NEW: CALL button - call specific station (cold call)
                let call_enabled = !self.their_call.is_empty();
                if ui.add_enabled(call_enabled, egui::Button::new("📞 CALL")).clicked() {
                    let _ = self.engine.cmds.send(UiCmd::CallStation {
                        my_call: self.my_call.clone(),
                        their_call: self.their_call.clone(),
                    });
                }
                
                ui.add_space(5.0);
                
                // Stop button - stop everything
                if ui.button("⏹ STOP").clicked() {
                    let _ = self.engine.cmds.send(UiCmd::Stop);
                }
            });

            ui.separator();
            
            // ===== Status display - shows last INFO line =====
            ui.horizontal(|ui| {
                ui.label("ℹ️ Status:");
                if let Some(last_info) = self.info_log.last() {
                    ui.monospace(last_info);
                } else {
                    ui.monospace("Auto-sequencing enabled: Listens → Someone calls you → Auto responds → Auto exchange → QSO complete");
                }
            });
        });

        egui::CentralPanel::default().show(ctx, |ui| {
            let mut clicked_call: Option<String> = None;
            
            ui.columns(3, |cols| {
                if let Some(call) = render_log(&mut cols[0], "RX", &self.rx_log) {
                    clicked_call = Some(call);
                }
                render_log(&mut cols[1], "TX", &self.tx_log);
                // NEW: Show CQ log instead of INFO log
                if let Some(call) = render_log(&mut cols[2], "CQ", &self.cq_log) {
                    clicked_call = Some(call);
                }
            });
            
            // Handle clicked callsign - start QSO
            if let Some(their_call) = clicked_call {
                log::info!("Starting QSO with {}", their_call);
                
                // ✅ Update Remote Call field immediately
                self.their_call = their_call.clone();
                
                // Send THEM de ME <REPORT> command
                // This goes to CallingStn state which will send the call + report
                let _ = self.engine.cmds.send(UiCmd::AnswerCq {
                    my_call: self.my_call.clone(),
                    their_call: their_call.clone(),
                    rpt: 26,  // Default report, will be computed from decode quality
                });
                
                // Show in info log
                push_cap(&mut self.info_log, format!("Answering CQ from {}", their_call));
            }
        });

        ctx.request_repaint();
    }
}

fn enumerate_audio_devices() -> (Vec<String>, Vec<String>) {
    let host = cpal::default_host();

    let mut ins = Vec::<String>::new();
    if let Ok(devs) = host.input_devices() {
        for d in devs {
            if let Ok(name) = d.name() {
                ins.push(name);
            }
        }
    }

    let mut outs = Vec::<String>::new();
    if let Ok(devs) = host.output_devices() {
        for d in devs {
            if let Ok(name) = d.name() {
                outs.push(name);
            }
        }
    }

    ins.sort();
    ins.dedup();
    outs.sort();
    outs.dedup();

    (ins, outs)
}

fn render_log(ui: &mut egui::Ui, title: &str, lines: &[String]) -> Option<String> {
    let mut clicked_call: Option<String> = None;
    
    ui.vertical(|ui| {
        ui.heading(title);

        egui::ScrollArea::vertical()
            .id_source(format!("scroll_{}", title))
            .stick_to_bottom(true)
            .show(ui, |ui| {
                for l in lines {
                    // Make RX and CQ logs clickable to start QSO
                    if title == "RX" || title == "CQ" {
                        if ui.selectable_label(false, l).clicked() {
                            // Extract callsign from "CQ de CALL" format
                            if let Some(call) = extract_callsign_from_cq(l) {
                                log::info!("Clicked on CQ from: {}", call);
                                clicked_call = Some(call);
                            }
                        }
                    } else {
                        ui.monospace(l);
                    }
                }
            });
    });
    
    clicked_call
}

fn push_cap(v: &mut Vec<String>, s: String) {
    const CAP: usize = 200;
    if v.len() >= CAP {
        v.remove(0);
    }
    v.push(s);
}

/// Extract callsign from "CQ de CALL" or "CQ CALL" format
fn extract_callsign_from_cq(text: &str) -> Option<String> {
    let text_upper = text.to_uppercase();
    
    // Check for "CQ de CALL" format
    if text_upper.contains("CQ") && text_upper.contains(" DE ") {
        let parts: Vec<&str> = text_upper.split(" DE ").collect();
        if parts.len() == 2 {
            // Get first word after "de"
            let after_de = parts[1].trim();
            if let Some(call) = after_de.split_whitespace().next() {
                return Some(call.to_string());
            }
        }
    }
    
    // Check for "CQ CALL" format
    if text_upper.starts_with("CQ ") {
        let words: Vec<&str> = text_upper.split_whitespace().collect();
        if words.len() >= 2 && words[0] == "CQ" {
            // Second word is the callsign
            return Some(words[1].to_string());
        }
    }
    
    None
}
