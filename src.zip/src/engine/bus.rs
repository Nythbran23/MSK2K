// src/engine/bus.rs
use tokio::sync::mpsc;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SlotParity {
    Odd,
    Even,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SlotPeriod {
    S15,
    S30,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PublicKind {
    Cq,
    Qrz,
    QstText,
    CqQtfPeriod,
}

#[derive(Debug, Clone)]
pub enum UiCmd {
    // ===== QSO / operator actions (3 scenarios) =====
    StartCq { my_call: String, auto_slots: bool },
    AnswerCq { my_call: String, their_call: String, rpt: i16 },
    ColdCall { my_call: String, their_call: String },
    
    // ✅ NEW: Call a specific station (initiates QSO by calling them with report)
    CallStation { my_call: String, their_call: String },

    SendReport { my_call: String, their_call: String, rpt: i16 },
    SendRReport { my_call: String, their_call: String, rpt: i16 },
    SendRr { my_call: String, their_call: String },
    Send73 { my_call: String, their_call: String },

    Listen { my_call: String, their_call: String, auto_slots: bool },
    Stop,

    // ===== Public messages (Format-1 “7.3 style” layer) =====
    PublicTx {
        my_call: String,
        kind: PublicKind,
        text10: Option<String>, // for QST free text (we’ll clamp later)
        qtf_deg: Option<i16>,   // for CQ QTF
        period_ms: Option<u32>, // for CQ P
        auto_slots: bool,
    },

    // ===== Audio / timing controls =====
    SetInputDevice(Option<String>),
    SetOutputDevice(Option<String>),
    ApplyAudio,

    SetSlotParity(SlotParity),
    SetSlotPeriod(SlotPeriod),

    SetAutoQso(bool),
}

#[derive(Debug, Clone)]
pub enum UiEvent {
    Info(String),
    State(String),
    TxText { text: String },
    RxText { text: String, snr: Option<f32>, utc_ms: i64, rx_slot: u8 },
    
    // ✅ NEW: Notify UI when their_call changes (for auto-populating Remote Call field)
    TheirCallChanged { callsign: String },
    
    // ✅ NEW: Notify UI when TX slot is auto-adjusted
    TxSlotChanged { slot: SlotParity },
}

// IMPORTANT: Receiver is not Clone; don't derive Clone on EngineHandle
pub struct EngineHandle {
    pub cmds: mpsc::UnboundedSender<UiCmd>,
    pub events: mpsc::UnboundedReceiver<UiEvent>,

    // Keep the Tokio runtime alive for background tasks
    pub(crate) _rt: tokio::runtime::Runtime,
}