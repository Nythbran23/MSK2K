// src/engine/runtime.rs
//
// Main engine runtime - integrates QSO state machine with audio RX/TX.
//
// Architecture:
// - QsoEngine (pure state machine) handles protocol logic
// - Runtime handles timeslots, audio workers, and UI events
// - proto module bridges DSP messages to protocol payloads

use anyhow::Result;
use std::time::{Duration, SystemTime, UNIX_EPOCH};
use tokio::sync::mpsc;
use tokio::time::sleep;

use crate::engine::bus::{EngineHandle, SlotParity, SlotPeriod, UiCmd, UiEvent};
use crate::modem::{run_receiver, run_transmitter_task, RxAudioCfg, RxDecoded, TxRequest};
use crate::proto::{self, Format, RxEnvelope, render_payload};
use crate::qso::{Action, EngineEvent, Intent, QsoEngine, QsoState};

pub fn start() -> EngineHandle {
    let rt = tokio::runtime::Runtime::new().expect("tokio runtime");
    let (cmds, cmd_rx) = mpsc::unbounded_channel::<UiCmd>();
    let (evt_tx, events) = mpsc::unbounded_channel::<UiEvent>();

    rt.spawn(async move {
        if let Err(e) = run_runtime(cmd_rx, evt_tx).await {
            log::error!("engine runtime crashed: {e}");
        }
    });

    EngineHandle { cmds, events, _rt: rt }
}

fn utc_ms_now() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_millis() as i64
}

fn slot_len_ms(period: SlotPeriod) -> i64 {
    match period {
        SlotPeriod::S15 => 15_000,
        SlotPeriod::S30 => 30_000,
    }
}

fn slot_index(utc_ms: i64, slot_len_ms: i64) -> i64 {
    if slot_len_ms <= 0 {
        return 0;
    }
    utc_ms / slot_len_ms
}

fn slot_parity(utc_ms: i64, slot_len_ms: i64) -> u8 {
    (slot_index(utc_ms, slot_len_ms) % 2) as u8
}

async fn run_runtime(
    mut cmd_rx: mpsc::UnboundedReceiver<UiCmd>,
    evt_tx: mpsc::UnboundedSender<UiEvent>,
) -> Result<()> {
    // ---------------- TX worker ----------------
    let (tx_req_tx, tx_req_rx) = mpsc::unbounded_channel::<TxRequest>();
    tokio::spawn(async move {
        if let Err(e) = run_transmitter_task(tx_req_rx).await {
            log::error!("TX worker crashed: {e}");
        }
    });

    // ---------------- RX worker ----------------
    let (rx_decoded_tx, mut rx_decoded_rx) = mpsc::unbounded_channel::<RxDecoded>();
    let mut rx_stop_tx: Option<mpsc::UnboundedSender<()>> = None;

    // ---------------- Audio config ----------------
    let mut input_device: Option<String> = None;
    let mut output_device: Option<String> = None;
    let sample_rate: u32 = 48_000;
    let buffer_size: usize = 1024;
    let input_gain: f32 = 1.0;
    let output_level: f32 = 1.0;
    let decode_window_secs: f32 = 4.0;

    // ---------------- QSO Engine ----------------
    let mut qso_engine = QsoEngine::new(String::new());
    let mut auto_qso: bool = true;

    // ---------------- Timing ----------------
    let mut slot_period = SlotPeriod::S15;
    let mut slot_parity_cfg = SlotParity::Odd;
    let mut running = true;
    let mut last_slot_index: Option<i64> = None;
    
    // Which slot did the remote TX on (0/1). We TX on the opposite slot.
    let mut observed_remote_slot: Option<u8> = None;
    
    // Resume CQ flag after QSO completes
    let mut was_calling_cq: bool = false;
    
    // Restart RX when cfg changes
    let mut rx_needs_restart: bool = true;

    log::info!("🚀 Engine starting - waiting for callsign");
    let _ = evt_tx.send(UiEvent::Info("Enter callsign and press LISTEN or CQ".into()));

    loop {
        tokio::select! {
            // ================================================================
            // PERIODIC TICK: Handle timeslots and auto-TX
            // ================================================================
            _ = sleep(Duration::from_millis(50)) => {
                if !running {
                    continue;
                }

                let now_ms = utc_ms_now();
                let slen = slot_len_ms(slot_period);
                let sidx = slot_index(now_ms, slen);
                let slot = slot_parity(now_ms, slen);

                // Configured base TX slot
                let base_tx_slot: u8 = match slot_parity_cfg {
                    SlotParity::Odd => 1,
                    SlotParity::Even => 0,
                };

                // If locked to remote, TX opposite the remote's slot
                let my_tx_slot: u8 = if let Some(remote) = observed_remote_slot {
                    1 - remote
                } else {
                    base_tx_slot
                };

                // Determine if we should TX this slot based on QSO state
                let is_tx_state = matches!(
                    qso_engine.state,
                    QsoState::CallingCq | 
                    QsoState::CallingStn | 
                    QsoState::WaitingRReport |
                    QsoState::WaitingRr |
                    QsoState::Waiting73 |
                    QsoState::Sending73
                );

                let should_tx = is_tx_state && (slot == my_tx_slot);
                
                // Determine if we should listen to all slots (when not in active QSO)
                let listen_all_slots = matches!(
                    qso_engine.state,
                    QsoState::Idle | QsoState::Listening
                );

                // Start/restart RX as needed
                if rx_needs_restart && !qso_engine.my_call.is_empty() {
                    restart_rx(&rx_decoded_tx, &mut rx_stop_tx, RxAudioCfg {
                        input_device: input_device.clone(),
                        sample_rate,
                        buffer_size,
                        slot_len_ms: slen as u32,
                        input_gain,
                        my_call: qso_engine.my_call.clone(),
                        their_call: qso_engine.their_call.clone(),
                        decode_window_secs,
                        my_tx_slot,
                        rx_slot_override: observed_remote_slot,
                        listen_all_slots,
                    });
                    rx_needs_restart = false;
                }

                // Act once per slot boundary
                if last_slot_index.is_none() || sidx != last_slot_index.unwrap() {
                    last_slot_index = Some(sidx);

                    if should_tx {
                        log::info!(
                            "📡 TX slot {} (state={}, remote={:?} => my_tx_slot={})",
                            slot,
                            qso_engine.state,
                            observed_remote_slot,
                            my_tx_slot
                        );

                        // Get next TX from QSO engine
                        if let Some(payload) = qso_engine.next_tx() {
                            let raw = render_payload(&payload);
                            
                            let _ = evt_tx.send(UiEvent::TxText { text: raw.clone() });

                            let _ = tx_req_tx.send(TxRequest::Text {
                                rendered: raw,
                                slot_len_ms: slen as u32,
                                my_call: qso_engine.my_call.clone(),
                                their_call: qso_engine.their_call.clone().unwrap_or_default(),
                            });

                            // Track 73 repeats for timeout
                            if qso_engine.state == QsoState::Waiting73 
                                || qso_engine.state == QsoState::Sending73
                                || qso_engine.state == QsoState::Done 
                            {
                                qso_engine.tx_repeat_count += 1;
                                
                                // Stop after 5 transmissions for Sending73 state
                                let max_73_repeats = if qso_engine.state == QsoState::Sending73 { 5 } else { qso_engine.max_repeats };
                                
                                if qso_engine.tx_repeat_count >= max_73_repeats {
                                    let their = qso_engine.their_call.clone().unwrap_or_default();
                                    log::info!("73 timeout - QSO with {} complete", their);
                                    
                                    // Reset and possibly resume CQ
                                    if was_calling_cq {
                                        let _ = qso_engine.on_intent(Intent::Cq);
                                        observed_remote_slot = None;
                                        let _ = evt_tx.send(UiEvent::Info("Returning to CQ mode".into()));
                                    } else {
                                        let _ = qso_engine.on_intent(Intent::Listen);
                                        observed_remote_slot = None;
                                        let _ = evt_tx.send(UiEvent::Info("Returning to LISTEN mode".into()));
                                    }
                                    
                                    rx_needs_restart = true;
                                }
                            }
                        }
                    }
                }
            }

            // ================================================================
            // UI COMMANDS
            // ================================================================
            Some(cmd) = cmd_rx.recv() => {
                match cmd {
                    UiCmd::SetInputDevice(dev) => {
                        input_device = dev;
                        rx_needs_restart = true;
                    }
                    
                    UiCmd::SetOutputDevice(dev) => {
                        output_device = dev;
                    }
                    
                    UiCmd::SetSlotPeriod(p) => {
                        slot_period = p;
                        last_slot_index = None;
                        rx_needs_restart = true;
                    }
                    
                    UiCmd::SetSlotParity(p) => {
                        slot_parity_cfg = p;
                        rx_needs_restart = true;
                    }
                    
                    UiCmd::SetAutoQso(on) => {
                        auto_qso = on;
                    }
                    
                    UiCmd::ApplyAudio => {
                        let _ = tx_req_tx.send(TxRequest::ApplyAudio {
                            output_device: output_device.clone(),
                            output_level,
                            sample_rate,
                            buffer_size,
                            my_call: qso_engine.my_call.clone(),
                            their_call: qso_engine.their_call.clone().unwrap_or_default(),
                        });
                        rx_needs_restart = true;
                        let _ = evt_tx.send(UiEvent::Info("Audio applied".into()));
                    }

                    UiCmd::Listen { my_call: mc, their_call: tc, auto_slots: _ } => {
                        if !mc.is_empty() {
                            qso_engine.set_my_call(mc);
                        } else if qso_engine.my_call.is_empty() {
                            let _ = evt_tx.send(UiEvent::Info("ERROR: Set My Call field!".into()));
                            continue;
                        }

                        if !tc.is_empty() {
                            qso_engine.set_their_call(Some(tc));
                        } else {
                            qso_engine.set_their_call(None);
                        }
                        
                        let (_, events) = qso_engine.on_intent(Intent::Listen);
                        process_qso_events(&events, &evt_tx);
                        
                        running = true;
                        observed_remote_slot = None;
                        was_calling_cq = false;

                        let _ = tx_req_tx.send(TxRequest::ApplyAudio {
                            output_device: output_device.clone(),
                            output_level,
                            sample_rate,
                            buffer_size,
                            my_call: qso_engine.my_call.clone(),
                            their_call: qso_engine.their_call.clone().unwrap_or_default(),
                        });

                        rx_needs_restart = true;
                        let _ = evt_tx.send(UiEvent::Info("LISTEN mode".into()));
                    }

                    UiCmd::StartCq { my_call: mc, auto_slots: _ } => {
                        if !mc.is_empty() { 
                            qso_engine.set_my_call(mc); 
                        }
                        
                        let (_, events) = qso_engine.on_intent(Intent::Cq);
                        process_qso_events(&events, &evt_tx);
                        
                        running = true;
                        last_slot_index = None;
                        observed_remote_slot = None;
                        was_calling_cq = true;

                        let _ = tx_req_tx.send(TxRequest::ApplyAudio {
                            output_device: output_device.clone(),
                            output_level,
                            sample_rate,
                            buffer_size,
                            my_call: qso_engine.my_call.clone(),
                            their_call: "".to_string(),
                        });

                        rx_needs_restart = true;
                        let _ = evt_tx.send(UiEvent::Info("CQ mode".into()));
                    }

                    UiCmd::CallStation { my_call: mc, their_call: tc } => {
                        if !mc.is_empty() { 
                            qso_engine.set_my_call(mc); 
                        }
                        
                        let (_, events) = qso_engine.on_intent(Intent::Call { their: tc.clone() });
                        process_qso_events(&events, &evt_tx);
                        
                        let _ = evt_tx.send(UiEvent::TheirCallChanged { callsign: tc });

                        running = true;
                        last_slot_index = None;
                        observed_remote_slot = None;
                        was_calling_cq = false;

                        let _ = tx_req_tx.send(TxRequest::ApplyAudio {
                            output_device: output_device.clone(),
                            output_level,
                            sample_rate,
                            buffer_size,
                            my_call: qso_engine.my_call.clone(),
                            their_call: qso_engine.their_call.clone().unwrap_or_default(),
                        });

                        rx_needs_restart = true;
                    }
                    
                    UiCmd::ColdCall { my_call: mc, their_call: tc } => {
                        if !mc.is_empty() { 
                            qso_engine.set_my_call(mc); 
                        }
                        
                        let (_, events) = qso_engine.on_intent(Intent::Call { their: tc.clone() });
                        process_qso_events(&events, &evt_tx);
                        
                        let _ = evt_tx.send(UiEvent::TheirCallChanged { callsign: tc });

                        running = true;
                        last_slot_index = None;
                        observed_remote_slot = None;
                        was_calling_cq = false;

                        let _ = tx_req_tx.send(TxRequest::ApplyAudio {
                            output_device: output_device.clone(),
                            output_level,
                            sample_rate,
                            buffer_size,
                            my_call: qso_engine.my_call.clone(),
                            their_call: qso_engine.their_call.clone().unwrap_or_default(),
                        });

                        rx_needs_restart = true;
                    }

                    UiCmd::AnswerCq { my_call: mc, their_call: tc, rpt } => {
                        if !mc.is_empty() { 
                            qso_engine.set_my_call(mc); 
                        }
                        
                        qso_engine.set_my_report(rpt);
                        
                        let (_, events) = qso_engine.on_intent(Intent::AnswerCq { 
                            their: tc.clone(), 
                            rpt 
                        });
                        process_qso_events(&events, &evt_tx);

                        running = true;
                        last_slot_index = None;
                        was_calling_cq = false;

                        let _ = tx_req_tx.send(TxRequest::ApplyAudio {
                            output_device: output_device.clone(),
                            output_level,
                            sample_rate,
                            buffer_size,
                            my_call: qso_engine.my_call.clone(),
                            their_call: qso_engine.their_call.clone().unwrap_or_default(),
                        });

                        rx_needs_restart = true;
                    }
                    
                    UiCmd::SendReport { my_call: mc, their_call: tc, rpt } => {
                        if !mc.is_empty() { 
                            qso_engine.set_my_call(mc); 
                        }
                        if !tc.is_empty() { 
                            qso_engine.set_their_call(Some(tc)); 
                        }
                        
                        let (_, events) = qso_engine.on_intent(Intent::SendReport { rpt });
                        process_qso_events(&events, &evt_tx);
                        rx_needs_restart = true;
                    }
                    
                    UiCmd::SendRReport { my_call: mc, their_call: tc, rpt } => {
                        if !mc.is_empty() { 
                            qso_engine.set_my_call(mc); 
                        }
                        if !tc.is_empty() { 
                            qso_engine.set_their_call(Some(tc)); 
                        }
                        
                        let (_, events) = qso_engine.on_intent(Intent::SendRReport { rpt });
                        process_qso_events(&events, &evt_tx);
                        rx_needs_restart = true;
                    }
                    
                    UiCmd::SendRr { my_call: mc, their_call: tc } => {
                        if !mc.is_empty() { 
                            qso_engine.set_my_call(mc); 
                        }
                        if !tc.is_empty() { 
                            qso_engine.set_their_call(Some(tc)); 
                        }
                        
                        let (_, events) = qso_engine.on_intent(Intent::SendRr);
                        process_qso_events(&events, &evt_tx);
                        rx_needs_restart = true;
                    }
                    
                    UiCmd::Send73 { my_call: mc, their_call: tc } => {
                        if !mc.is_empty() { 
                            qso_engine.set_my_call(mc); 
                        }
                        if !tc.is_empty() { 
                            qso_engine.set_their_call(Some(tc)); 
                        }
                        
                        let (_, events) = qso_engine.on_intent(Intent::Send73);
                        process_qso_events(&events, &evt_tx);
                        rx_needs_restart = true;
                    }

                    UiCmd::Stop => {
                        running = false;
                        let (_, events) = qso_engine.on_intent(Intent::Abort);
                        process_qso_events(&events, &evt_tx);
                        
                        observed_remote_slot = None;
                        was_calling_cq = false;

                        if let Some(st) = rx_stop_tx.take() {
                            let _ = st.send(());
                        }
                        let _ = tx_req_tx.send(TxRequest::Stop);

                        let _ = evt_tx.send(UiEvent::Info("STOPPED".into()));
                    }
                    
                    UiCmd::PublicTx { .. } => {
                        // TODO: Handle public messages (QST, etc.)
                        log::warn!("PublicTx not yet implemented");
                    }
                }
            }

            // ================================================================
            // RX DECODE: Process decoded messages through QSO engine
            // ================================================================
            Some(decoded) = rx_decoded_rx.recv() => {
                let text = &decoded.msg.text;
                let from_call = &decoded.msg.from_call;

                // Always push to UI first
                let _ = evt_tx.send(UiEvent::RxText {
                    text: text.clone(),
                    snr: decoded.snr,
                    utc_ms: decoded.utc_ms,
                    rx_slot: decoded.rx_slot,
                });

                // Loopback protection
                if !qso_engine.my_call.is_empty() 
                    && from_call.to_uppercase() == qso_engine.my_call.to_uppercase() 
                {
                    log::warn!("LOOPBACK: ignoring decode from own callsign: {}", from_call);
                    continue;
                }

                // Convert DSP message to protocol payload
                let payload = match proto::message_to_payload(&decoded.msg) {
                    Some(p) => p,
                    None => {
                        log::debug!("Could not convert message to payload: {:?}", decoded.msg);
                        continue;
                    }
                };

                // Lock remote slot from UTC-derived rx_slot
                if observed_remote_slot.is_none()
                    || qso_engine.state == QsoState::Listening
                    || qso_engine.state == QsoState::CallingCq
                {
                    observed_remote_slot = Some(decoded.rx_slot);
                    let my_new_tx_slot = 1 - decoded.rx_slot;
                    log::info!(
                        "🔒 Locked remote_slot={} => my_tx_slot={}",
                        decoded.rx_slot,
                        my_new_tx_slot
                    );
                    
                    // Notify UI of slot change
                    let slot_parity = if my_new_tx_slot == 0 { SlotParity::Even } else { SlotParity::Odd };
                    let _ = evt_tx.send(UiEvent::TxSlotChanged { slot: slot_parity });
                    
                    rx_needs_restart = true;
                }

                // Create RX envelope for QSO engine
                let rx_env = RxEnvelope {
                    payload,
                    format: if decoded.msg.format == 1 { Format::Fmt1 } else { Format::Fmt2 },
                    snr: decoded.snr,
                    utc_ms: decoded.utc_ms,
                    rx_slot: decoded.rx_slot,
                };

                // Process through QSO engine
                if auto_qso {
                    let (action, events) = qso_engine.on_rx(rx_env);
                    
                    // Process events
                    for event in &events {
                        match event {
                            EngineEvent::StateChanged(state) => {
                                let _ = evt_tx.send(UiEvent::State(state.to_string()));
                            }
                            EngineEvent::Info(msg) => {
                                let _ = evt_tx.send(UiEvent::Info(msg.clone()));
                            }
                            EngineEvent::TheirCallChanged { callsign } => {
                                let _ = evt_tx.send(UiEvent::TheirCallChanged { 
                                    callsign: callsign.clone() 
                                });
                                rx_needs_restart = true;
                            }
                            EngineEvent::QsoComplete { their } => {
                                let _ = evt_tx.send(UiEvent::Info(
                                    format!("✓ QSO with {} complete", their)
                                ));
                                
                                // Clear remote call in UI
                                let _ = evt_tx.send(UiEvent::TheirCallChanged { 
                                    callsign: String::new() 
                                });
                                
                                // Auto-return to CQ or Listen
                                if was_calling_cq {
                                    let (_, events) = qso_engine.on_intent(Intent::Cq);
                                    process_qso_events(&events, &evt_tx);
                                    observed_remote_slot = None;
                                } else {
                                    let (_, events) = qso_engine.on_intent(Intent::Listen);
                                    process_qso_events(&events, &evt_tx);
                                    observed_remote_slot = None;
                                }
                                rx_needs_restart = true;
                            }
                            _ => {}
                        }
                    }
                    
                    // Handle action (if engine wants to transmit)
                    if let Action::Transmit(tx_env) = action {
                        let _ = evt_tx.send(UiEvent::TxText { text: tx_env.raw.clone() });
                        
                        let _ = tx_req_tx.send(TxRequest::Text {
                            rendered: tx_env.raw,
                            slot_len_ms: slot_len_ms(slot_period) as u32,
                            my_call: qso_engine.my_call.clone(),
                            their_call: qso_engine.their_call.clone().unwrap_or_default(),
                        });
                    }
                }
            }

            else => break,
        }
    }

    Ok(())
}

fn restart_rx(
    rx_decoded_tx: &mpsc::UnboundedSender<RxDecoded>,
    rx_stop_tx: &mut Option<mpsc::UnboundedSender<()>>,
    cfg: RxAudioCfg,
) {
    if let Some(st) = rx_stop_tx.take() {
        let _ = st.send(());
    }

    let (stop_tx, stop_rx) = mpsc::unbounded_channel();
    *rx_stop_tx = Some(stop_tx);

    log::info!(
        "🎧 RX start: my={} their={:?} slot_len_ms={} my_tx_slot={} rx_slot_override={:?} listen_all={}",
        cfg.my_call, cfg.their_call, cfg.slot_len_ms, cfg.my_tx_slot, cfg.rx_slot_override, cfg.listen_all_slots
    );

    tokio::spawn(run_receiver(cfg, rx_decoded_tx.clone(), stop_rx));
}

/// Process QSO engine events and forward relevant ones to UI
fn process_qso_events(events: &[EngineEvent], evt_tx: &mpsc::UnboundedSender<UiEvent>) {
    for event in events {
        match event {
            EngineEvent::StateChanged(state) => {
                let _ = evt_tx.send(UiEvent::State(state.to_string()));
            }
            EngineEvent::Info(msg) => {
                let _ = evt_tx.send(UiEvent::Info(msg.clone()));
            }
            EngineEvent::TheirCallChanged { callsign } => {
                let _ = evt_tx.send(UiEvent::TheirCallChanged { callsign: callsign.clone() });
            }
            EngineEvent::Tx(tx_env) => {
                let _ = evt_tx.send(UiEvent::TxText { text: tx_env.raw.clone() });
            }
            EngineEvent::QsoComplete { their } => {
                let _ = evt_tx.send(UiEvent::Info(format!("✓ QSO with {} complete", their)));
                // Clear remote call in UI
                let _ = evt_tx.send(UiEvent::TheirCallChanged { callsign: String::new() });
            }
            _ => {}
        }
    }
}
