// src/modem/rx.rs
// Slot-aware continuous RX:
// - Capture audio continuously.
// - Only FEED decoder during our RX slot (i.e. NOT during our TX slot) to avoid self-audio loopback churn.
// - Periodically (every ~2 seconds) attempt decode on accumulated buffer for faster feedback.
// - At RX-slot boundary, kick a final "accumulation" pass over the whole captured slot buffer.
//
// Notes:
// - decode_audio() is a one-shot API requiring enough samples for a full packet (~258 bits).
// - Minimum useful buffer is about 0.5 seconds (1000+ samples at 2000 baud).

use anyhow::Result;
use tokio::sync::mpsc;

use msk2k_audio::{AudioConfig, AudioInput, DeviceManager};
use msk2k_dsp::decoder_hybrid::HybridDecoder;
use msk2k_dsp::message::Message;

use std::time::{SystemTime, UNIX_EPOCH};

/// Minimum samples needed for a decode attempt.
/// 258 bits at 2000 baud = 129ms, at 48kHz = ~6200 samples.
/// We use a bit more for safety margin.
const MIN_DECODE_SAMPLES: usize = 12_000;

/// How often (in samples) to attempt a mid-slot decode.
/// ~2 seconds at 48kHz = 96000 samples.
const MID_SLOT_DECODE_INTERVAL: usize = 96_000;

#[derive(Debug, Clone)]
pub struct RxAudioCfg {
    pub input_device: Option<String>,
    pub sample_rate: u32,
    pub buffer_size: usize,
    pub slot_len_ms: u32,
    pub input_gain: f32,

    /// Calls needed for Format-2 decoding.
    pub my_call: String,
    pub their_call: Option<String>,

    /// "Fast" decode runs continuously; this value is used only to size/log windowing.
    pub decode_window_secs: f32,

    /// If set, the RX worker will prefer decoding on this slot (0/1) when we are in a locked QSO.
    /// Runtime currently uses this as "remote slot" (where the other station transmits).
    pub rx_slot_override: Option<u8>,

    /// Our TX slot (0/1). When the current slot == my_tx_slot, we stop feeding the decoder
    /// (but we may still be running a backlog/accumulation decode in the background).
    pub my_tx_slot: u8,
    
    /// When true, listen on ALL slots (both odd and even) - used when not in active QSO.
    /// When false, only listen on the RX slot (opposite of my_tx_slot).
    pub listen_all_slots: bool,
}

#[derive(Debug, Clone)]
pub struct RxDecoded {
    pub msg: Message,
    pub snr: Option<f32>,
    pub utc_ms: i64,
    pub rx_slot: u8,
}

fn utc_ms_now() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis() as i64
}

fn slot_index(utc_ms: i64, slot_len_ms: u32) -> i64 {
    let sl = slot_len_ms.max(1) as i64;
    utc_ms / sl
}

fn slot_parity(utc_ms: i64, slot_len_ms: u32) -> u8 {
    (slot_index(utc_ms, slot_len_ms) % 2) as u8
}

/// Spawn an "accumulation" decode over the full-slot buffer.
/// This runs while TX is happening.
fn spawn_accum_decode(
    slot_audio: Vec<f32>,
    cfg: RxAudioCfg,
    decoded_tx: mpsc::UnboundedSender<RxDecoded>,
    slot_end_utc_ms: i64,
    slot_rx_slot: u8,
) {
    // Avoid spawning empty/too-short work.
    if slot_audio.len() < (cfg.sample_rate as usize / 4) {
        return;
    }

    tokio::spawn(async move {
        // Fresh decoder for the accumulation pass.
        let decoder = HybridDecoder::new().with_calls(
            &cfg.my_call,
            cfg.their_call.as_deref().unwrap_or(""),
        );

        // One-shot API: run decode once over the full buffer.
        if let Some(msg) = decoder.decode_audio(&slot_audio) {
            // Drop obvious self-loopback early.
            if !cfg.my_call.is_empty() && msg.from_call.eq_ignore_ascii_case(&cfg.my_call) {
                return;
            }

            let _ = decoded_tx.send(RxDecoded {
                msg,
                snr: None,
                utc_ms: slot_end_utc_ms,
                rx_slot: slot_rx_slot,
            });
        }
    });
}

pub async fn run_receiver(
    cfg: RxAudioCfg,
    decoded_tx: mpsc::UnboundedSender<RxDecoded>,
    mut stop_rx: mpsc::UnboundedReceiver<()>,
) -> Result<()> {
    // Device selection
    let dm = DeviceManager::new()?;
    let dev = dm.get_input_device(cfg.input_device.as_deref())?;

    // Audio config (AudioConfig::new(sample_rate, channels, buffer_size))
    let acfg = AudioConfig::new(cfg.sample_rate, 1, cfg.buffer_size);

    // Audio pipeline: AudioInput -> audio_rx
    let (audio_tx, mut audio_rx) = mpsc::unbounded_channel::<Vec<f32>>();

    let mut input = AudioInput::new(dev, acfg);
    input.start(audio_tx)?;

    // Slot buffering
    let mut current_slot_idx: Option<i64> = None;
    let mut slot_buf: Vec<f32> = Vec::new();
    let mut last_mid_decode_len: usize = 0;  // Track when we last did a mid-slot decode
    let mut last_decoded_text: Option<String> = None;  // Dedup consecutive decodes

    log::info!(
        "🎧 RX started: my_call='{}', their_call='{}', slot_len_ms={}, my_tx_slot={} (override={:?}) listen_all={}",
        cfg.my_call,
        cfg.their_call.as_deref().unwrap_or("<none>"),
        cfg.slot_len_ms,
        cfg.my_tx_slot,
        cfg.rx_slot_override,
        cfg.listen_all_slots
    );

    loop {
        tokio::select! {
            _ = stop_rx.recv() => {
                let _ = input.stop();
                log::info!("🛑 RX stopped");
                break;
            }

            Some(buf) = audio_rx.recv() => {
                let now_ms = utc_ms_now();
                let sl_ms = cfg.slot_len_ms.max(1);

                let idx = slot_index(now_ms, sl_ms);
                let slot = (idx % 2) as u8;

                // On slot boundary, if we were in an RX slot, run accumulation on the completed slot buffer.
                if let Some(prev_idx) = current_slot_idx {
                    if idx != prev_idx {
                        let prev_slot = (prev_idx % 2) as u8;
                        // Decode if: listening all slots OR this was our RX slot
                        let should_decode = cfg.listen_all_slots || prev_slot != cfg.my_tx_slot;
                        if should_decode {
                            let finished = std::mem::take(&mut slot_buf);
                            spawn_accum_decode(
                                finished,
                                cfg.clone(),
                                decoded_tx.clone(),
                                now_ms,
                                prev_slot,
                            );
                        } else {
                            // We were transmitting; discard any accumulated junk.
                            slot_buf.clear();
                        }
                        // Reset mid-slot tracking for new slot
                        last_mid_decode_len = 0;
                        last_decoded_text = None;
                    }
                }
                current_slot_idx = Some(idx);

                // Apply input gain
                let gain = cfg.input_gain;
                let mut tmp: Vec<f32> = buf;
                if (gain - 1.0).abs() > f32::EPSILON {
                    for s in &mut tmp {
                        *s *= gain;
                    }
                }

                // If it's our TX slot and we're not listening to all slots, do NOT feed decoder
                // (prevents endless self-audio churn during active QSO).
                if !cfg.listen_all_slots && slot == cfg.my_tx_slot {
                    continue;
                }

                // Capture for accumulation pass.
                slot_buf.extend_from_slice(&tmp);

                // Mid-slot decode: attempt decode periodically on accumulated buffer.
                // Only try if we have enough samples and haven't tried recently.
                let samples_since_last = slot_buf.len().saturating_sub(last_mid_decode_len);
                if slot_buf.len() >= MIN_DECODE_SAMPLES && samples_since_last >= MID_SLOT_DECODE_INTERVAL {
                    last_mid_decode_len = slot_buf.len();
                    
                    // Create decoder with current callsign context
                    let mid_decoder = HybridDecoder::new().with_calls(
                        &cfg.my_call,
                        cfg.their_call.as_deref().unwrap_or(""),
                    );
                    
                    // Try decode on current accumulated buffer
                    if let Some(msg) = mid_decoder.decode_audio(&slot_buf) {
                        // Skip loopback
                        if !cfg.my_call.is_empty() && msg.from_call.eq_ignore_ascii_case(&cfg.my_call) {
                            continue;
                        }
                        
                        // Dedup: skip if same message as last decode in this slot
                        let msg_key = format!("{}:{}", msg.from_call, msg.text);
                        if last_decoded_text.as_ref() != Some(&msg_key) {
                            last_decoded_text = Some(msg_key);
                            
                            log::info!("🔵 Mid-slot decode: {} from {}", msg.text, msg.from_call);
                            let _ = decoded_tx.send(RxDecoded {
                                msg,
                                snr: None,
                                utc_ms: now_ms,
                                rx_slot: slot,
                            });
                        }
                    }
                }

                // Safety: prevent runaway memory if UI sets something odd.
                // Keep at most ~1.25 slots worth buffered.
                let max_buf = ((cfg.sample_rate as usize) * ((sl_ms as usize) * 5) / 4000)
                    .max(cfg.sample_rate as usize);
                if slot_buf.len() > max_buf {
                    let drop = slot_buf.len() - max_buf;
                    slot_buf.drain(0..drop);
                }
            }
        }
    }

    Ok(())
}