// src/modem/tx.rs
//
// TX worker: UI/runtime sends TxRequest::Text { rendered, slot_len_ms }.
// We convert rendered string -> msk2k_dsp::message::Message,
// then generate real MSK2K waveform using your proven pipeline
// (fec/fmt1/fmt2 + MSK modulator) and push to audio output.
//
// No clever sequencing: transmit immediately.

use anyhow::{anyhow, Result};
use log::{info, warn};
use tokio::sync::mpsc;

use msk2k_audio::{AudioConfig, AudioOutput, AudioOutputBuilder, DeviceManager};
use msk2k_dsp::callsign::CallsignCodec;
use msk2k_dsp::message::Message;
use msk2k_dsp::{fec, fmt1, fmt2};

use std::f32::consts::PI;

use crate::modem::TxRequest;

const SYMBOL_RATE: u32 = 2_000;
const CENTER_FREQ: f32 = 1500.0;
const FREQ_DEV: f32 = 500.0;

// Public/general address for public packets
const GENERAL_ADDRESS_49: [i32; 49] = [0; 49];

#[derive(Debug, Clone)]
struct TxAudioCfg {
    output_device: Option<String>,
    output_level: f32,
    sample_rate: u32,
    buffer_size: usize,
    my_call: String,         // ✅ Need for Format-2 messages
    their_call: String,      // ✅ Need for Format-2 messages
}

impl Default for TxAudioCfg {
    fn default() -> Self {
        Self {
            output_device: None,
            output_level: 0.6,
            sample_rate: 48_000,
            buffer_size: 1024,
            my_call: String::new(),
            their_call: String::new(),
        }
    }
}

pub async fn run_transmitter_task(
    mut tx_req_rx: mpsc::UnboundedReceiver<TxRequest>,
) -> Result<()> {
    let mut cfg = TxAudioCfg::default();

    // Output stream + sender
    let mut out: Option<AudioOutput> = None;
    let mut audio_tx_opt: Option<mpsc::UnboundedSender<Vec<f32>>> = None;

    let codec = CallsignCodec::new();

    info!("[TX] worker started");

    while let Some(req) = tx_req_rx.recv().await {
        match req {
            TxRequest::ApplyAudio {
                output_device,
                output_level,
                sample_rate,
                buffer_size,
                my_call,
                their_call,
            } => {
                cfg.output_device = output_device;
                cfg.output_level = output_level;
                cfg.sample_rate = sample_rate;
                cfg.buffer_size = buffer_size;
                cfg.my_call = my_call.clone();
                cfg.their_call = their_call.clone();

                let (o, audio_tx) = build_output_and_sender(&cfg)?;
                out = Some(o);
                audio_tx_opt = Some(audio_tx);

                info!(
                    "[TX] ApplyAudio dev={:?} level={:.2} sr={} buf={} my={} their={}",
                    cfg.output_device, cfg.output_level, cfg.sample_rate, cfg.buffer_size,
                    cfg.my_call, cfg.their_call
                );
            }

            TxRequest::Stop => {
                out = None;
                audio_tx_opt = None;
                info!("[TX] STOP");
            }

            TxRequest::Text { rendered, slot_len_ms, my_call, their_call } => {
                // Lazy init if ApplyAudio was not pressed
                if out.is_none() || audio_tx_opt.is_none() {
                    let (o, audio_tx) = build_output_and_sender(&cfg)?;
                    out = Some(o);
                    audio_tx_opt = Some(audio_tx);
                }
                let audio_tx = audio_tx_opt.as_ref().unwrap();

                // ✅ Use callsigns from THIS request, not from cfg!
                // This ensures we always have current callsigns even if ApplyAudio hasn't processed yet
                info!("[TX] Text request: '{}' my={} their={}", rendered, my_call, their_call);

                // ✅ PYTHON LOGIC: Detect short Format-2 messages and add callsigns
                // Python (line 912-918): if msg in ("R26", "RR", "73"): generate_format2_message(my, their, msg)
                let is_short_fmt2 = is_short_format2(&rendered);
                info!("[TX] is_short_format2('{}') = {}", rendered, is_short_fmt2);
                
                let msg_result = if is_short_fmt2 {
                    // Short Format-2 message needs callsigns added
                    info!("[TX] Calling message_from_short_format2");
                    message_from_short_format2(&rendered, &my_call, &their_call)
                } else {
                    // Regular message parsing
                    info!("[TX] Calling message_from_rendered");
                    message_from_rendered(&rendered)
                };
                
                let msg = match msg_result {
                    Ok(m) => m,
                    Err(e) => {
                        warn!("[TX] Failed to parse '{}': {} - SKIPPING TX", rendered, e);
                        continue;  // Don't crash, just skip this TX
                    }
                };

                info!(
                    "[TX] TX: fmt={} from={} to={:?} text='{}'",
                    msg.format, msg.from_call, msg.to_call, msg.text
                );

                // Generate waveform (real modem TX)
                let waveform = match generate_transmission(&msg, &codec, cfg.sample_rate, slot_len_ms) {
                    Ok(w) => w,
                    Err(e) => {
                        warn!("[TX] Failed to generate waveform: {} - SKIPPING TX", e);
                        continue;
                    }
                };

                // Apply amplitude scaling only
                let scaled: Vec<f32> = waveform.iter().map(|&s| s * cfg.output_level).collect();

                if let Err(e) = audio_tx.send(scaled) {
                    warn!("[TX] Failed to send waveform to audio driver: {}", e);
                }
            }
        }
    }

    Ok(())
}

fn build_output_and_sender(cfg: &TxAudioCfg) -> Result<(AudioOutput, mpsc::UnboundedSender<Vec<f32>>)> {
    let manager = DeviceManager::new()?;

    let device = if let Some(ref name) = cfg.output_device {
        info!("[TX] Opening selected output device: {}", name);
        manager.get_output_device(Some(name)).or_else(|_| {
            warn!("[TX] Selected device '{}' not found, falling back to default.", name);
            manager.default_output_device()
        })?
    } else {
        manager.default_output_device()?
    };

    let audio_cfg = AudioConfig::new(cfg.sample_rate, 1, cfg.buffer_size);

    let mut out = AudioOutputBuilder::new()
        .device(device)
        .config(audio_cfg)
        .build()
        .map_err(|e| anyhow!("Failed to build AudioOutput: {e:?}"))?;

    let (audio_tx, audio_rx) = mpsc::unbounded_channel::<Vec<f32>>();
    out.start(audio_rx)?;

    Ok((out, audio_tx))
}

/// Rendered string -> DSP Message.
/// Strict mapping only (no guessing).
/// 
/// Runtime must provide callsigns in the rendered string for Format-2:
/// - "R26 FROM TO" for R-report
/// - "RR FROM TO" for roger roger
/// - "73 FROM TO" for seventy three
fn message_from_rendered(rendered: &str) -> Result<Message> {
    let s = rendered.trim();

    // CQ forms:
    //  - "CQ de <CALL>"
    //  - "CQ <CALL>"
    if s.starts_with("CQ") {
        let toks: Vec<&str> = s.split_whitespace().collect();

        if toks.len() >= 3 && toks[0] == "CQ" && toks[1].eq_ignore_ascii_case("de") {
            return Message::cq(toks[2]).map_err(|e| anyhow!("Message::cq failed: {e}"));
        }
        if toks.len() >= 2 && toks[0] == "CQ" {
            return Message::cq(toks[1]).map_err(|e| anyhow!("Message::cq failed: {e}"));
        }
        return Err(anyhow!("CQ missing callsign: '{}'", s));
    }

    // ✅ Format-2 messages (no "de" required)
    // Expected format from runtime: "RR FROM TO" or "73 FROM TO" or "R26 FROM TO"
    let toks: Vec<&str> = s.split_whitespace().collect();
    
    // Check for Format-2 patterns
    if toks.len() == 3 {
        let token = toks[0];
        let from = toks[1];
        let to = toks[2];
        
        if token == "RR" {
            return Message::roger_roger(from, to)
                .map_err(|e| anyhow!("Message::roger_roger failed: {e}"));
        }
        
        if token == "73" {
            return Message::seventy_three(from, to)
                .map_err(|e| anyhow!("Message::seventy_three failed: {e}"));
        }
        
        // R-report like "R26"
        if token.starts_with('R') && token.len() == 3 {
            return Message::call_with_report(from, to, token)
                .map_err(|e| anyhow!("Message::call_with_report failed: {e}"));
        }
    }

    // "<TO> de <FROM> [TOKEN]"
    let parts: Vec<&str> = s.split(" de ").collect();
    if parts.len() != 2 {
        return Err(anyhow!("Unrecognized TX string format: '{}'", s));
    }

    let to = parts[0].trim();
    let rhs = parts[1].trim();
    let mut toks = rhs.split_whitespace();

    let from = toks.next().ok_or_else(|| anyhow!("Missing FROM callsign"))?;
    let tail = toks.next(); // optional token

    match tail {
        None => Message::cold_call(from, to).map_err(|e| anyhow!("Message::cold_call failed: {e}")),
        Some("RR") => Message::roger_roger(from, to).map_err(|e| anyhow!("Message::roger_roger failed: {e}")),
        Some("73") => Message::seventy_three(from, to).map_err(|e| anyhow!("Message::seventy_three failed: {e}")),
        Some(tok) => {
            // report token like "26" or "R26"
            Message::call_with_report(from, to, tok)
                .map_err(|e| anyhow!("Message::call_with_report failed: {e}"))
        }
    }
}

fn vec_to_array<const N: usize>(v: Vec<i32>, what: &str) -> Result<[i32; N]> {
    if v.len() != N {
        return Err(anyhow!(
            "{} length mismatch: expected {} bits, got {}",
            what, N, v.len()
        ));
    }
    let mut arr = [0i32; N];
    arr.copy_from_slice(&v[..N]);
    Ok(arr)
}

fn generate_transmission(
    message: &Message,
    codec: &CallsignCodec,
    sample_rate: u32,
    slot_len_ms: u32,
) -> Result<Vec<f32>> {
    if sample_rate % SYMBOL_RATE != 0 {
        return Err(anyhow!(
            "sample_rate {} must be divisible by symbol rate {}",
            sample_rate,
            SYMBOL_RATE
        ));
    }
    let samples_per_symbol = (sample_rate / SYMBOL_RATE) as usize;

    let packet258: [i32; 258] = match message.format {
        1 => {
            let (info_vec, _) = message
                .to_format1_bits(codec)
                .map_err(|e| anyhow!("Format-1 bits encode error: {}", e))?;

            let info71: [i32; 71] = vec_to_array::<71>(info_vec, "Info Field")?;

            let addr49: [i32; 49] = if message.to_call.is_none() {
                GENERAL_ADDRESS_49
            } else {
                let to = message.to_call.as_ref().unwrap();
                let v = codec.generate_private_address(to).map_err(anyhow::Error::msg)?;
                // ✅ PYTHON FIX: generate_private_address() returns 50 bits, but we only use first 49!
                // Python line 257: "The private address is generate_private_address()[:49]"
                let v49 = v[..49.min(v.len())].to_vec();
                vec_to_array::<49>(v49, "Private Address")?
            };

            let (poly1_vec, poly2_vec) = fec::encode_format1(&info71);
            let poly1: [i32; 83] = vec_to_array::<83>(poly1_vec, "FEC Poly 1")?;
            let poly2: [i32; 83] = vec_to_array::<83>(poly2_vec, "FEC Poly 2")?;

            let sync43: [i32; 43] = fmt1::SYNC_PATTERN_HD43;
            let packet_vec = fmt1::interleave_format1(&sync43, &addr49, &poly1, &poly2);
            vec_to_array::<258>(packet_vec, "Interleaved Packet")?
        }

        2 => {
            let info18_vec = message
                .to_format2_bits(codec)
                .map_err(|e| anyhow!("Format-2 bits encode error: {}", e))?;
            let info18: [i32; 18] = vec_to_array::<18>(info18_vec, "Info18")?;

            let to = message.to_call.as_ref().ok_or_else(|| anyhow!("Format-2 requires to_call"))?;
            let addr_bits = codec.generate_private_address(to).map_err(anyhow::Error::msg)?;
            // ✅ PYTHON FIX: Only use first 49 bits (Python line 257)
            let addr_bits49 = addr_bits[..49.min(addr_bits.len())].to_vec();
            let addr49: [i32; 49] = vec_to_array::<49>(addr_bits49, "Private Address")?;

            let poly_dict = fec::encode_format2(&info18);

            let sync43: [i32; 43] = fmt1::SYNC_PATTERN_HD43;
            let packet_vec = fmt2::interleave_format2(&sync43, &addr49, &poly_dict);
            vec_to_array::<258>(packet_vec, "Interleaved Packet")?
        }

        other => return Err(anyhow!("Unsupported message format: {}", other)),
    };

    let symbols: Vec<i32> = packet258.iter().map(|&b| if b == 0 { 1 } else { -1 }).collect();

    let packet_waveform = generate_msk(&symbols, sample_rate, samples_per_symbol);

    // Fill requested duration by repeating/truncating (not “slot accurate”, just bounded)
    let target_samples = ((slot_len_ms as u64 * sample_rate as u64) / 1000) as usize;

    if target_samples == 0 {
        return Ok(packet_waveform);
    }

    let mut waveform: Vec<f32> = Vec::with_capacity(target_samples);
    while waveform.len() < target_samples {
        let remaining = target_samples - waveform.len();
        if remaining >= packet_waveform.len() {
            waveform.extend_from_slice(&packet_waveform);
        } else {
            waveform.extend_from_slice(&packet_waveform[..remaining]);
            break;
        }
    }

    Ok(waveform)
}

fn generate_msk(symbols: &[i32], sample_rate: u32, samples_per_symbol: usize) -> Vec<f32> {
    let mut samples = Vec::with_capacity(symbols.len() * samples_per_symbol);
    let mut phase = 0.0f32;

    for &symbol in symbols {
        let freq = CENTER_FREQ + (symbol as f32 * FREQ_DEV);
        let phase_step = 2.0 * PI * freq / sample_rate as f32;

        for _ in 0..samples_per_symbol {
            phase += phase_step;
            samples.push(0.5 * phase.sin());
            if phase > 2.0 * PI {
                phase -= 2.0 * PI;
            }
        }
    }

    samples
}

// ✅ PYTHON LOGIC (line 912): Detect short Format-2 messages
fn is_short_format2(s: &str) -> bool {
    let s = s.trim();
    
    warn!("[TX DEBUG] is_short_format2('{}') len={}", s, s.len());
    
    // Check for exact matches
    if s == "RR" || s == "RRR" || s == "73" {
        warn!("[TX DEBUG] Matched exact: {}", s);
        return true;
    }
    
    // Check for R-reports (R26, R27, etc.)
    if s.starts_with('R') && s.len() == 3 {
        warn!("[TX DEBUG] starts with R, len=3: {}", s);
        let suffix = &s[1..];
        warn!("[TX DEBUG] suffix='{}', parsing...", suffix);
        if let Ok(num) = suffix.parse::<u32>() {
            warn!("[TX DEBUG] ✅ Parsed {} as number, returning TRUE", num);
            return true;
        } else {
            warn!("[TX DEBUG] ❌ Failed to parse '{}' as number", suffix);
        }
    }
    
    warn!("[TX DEBUG] ❌ No match, returning FALSE");
    false
}

// ✅ Handle short Format-2 messages by adding callsigns
fn message_from_short_format2(s: &str, my_call: &str, their_call: &str) -> Result<Message> {
    let s = s.trim();
    
    if my_call.is_empty() || their_call.is_empty() {
        return Err(anyhow!("Short Format-2 message '{}' needs both callsigns, got my='{}' their='{}'", 
                          s, my_call, their_call));
    }
    
    if s == "RR" || s == "RRR" {
        return Message::roger_roger(my_call, their_call)
            .map_err(|e| anyhow!("Message::roger_roger failed: {e}"));
    }
    
    if s == "73" {
        return Message::seventy_three(my_call, their_call)
            .map_err(|e| anyhow!("Message::seventy_three failed: {e}"));
    }
    
    // R-reports - these are Format-2!
    if s.starts_with('R') && s.len() == 3 {
        // ✅ R-reports like "R26" are Format-2, not Format-1!
        return Message::format2(my_call, their_call, s)
            .map_err(|e| anyhow!("Message::format2 failed: {e}"));
    }
    
    Err(anyhow!("Not a short Format-2 message: '{}'", s))
}