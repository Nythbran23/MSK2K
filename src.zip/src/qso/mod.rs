// src/qso/mod.rs
//
// Pure, deterministic QSO/session state machine.
// No egui, no audio, no tokio. Easy to unit test.
//
// Region-1 Meteor Scatter Ladder:
// ================================
// 
// Station A (CQ caller):                Station B (responder):
// 1. CQ de A                     ->
//                                <-     2. A de B 27  (call + report)
// 3. B de A 27  (report)         ->
//                                <-     4. R27        (roger-report)
// 5. RR                          ->
//                                <-     6. 73
// 7. 73                          ->     [QSO complete]
//
// The state machine tracks which step we're at and what we expect next.

#[allow(unused_imports)]  // Format used in tests
use crate::proto::{render_payload, Format, Payload, RxEnvelope, TxEnvelope};

/// QSO protocol states
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum QsoState {
    /// Not active
    Idle,
    
    /// Listening for activity (will respond to calls addressed to us)
    Listening,
    
    /// Calling CQ, waiting for someone to answer
    CallingCq,
    
    /// Calling a specific station (cold call, no report yet)
    CallingStn,
    
    /// Sent our report, waiting for their report back
    /// (Step 3 done, waiting for step 4)
    WaitingRReport,
    
    /// Received their R-report, need to send RR
    /// (Step 4 received, will send step 5)
    WaitingRr,
    
    /// Sent RR, waiting for their 73
    /// (Step 5 done, waiting for step 6)
    Waiting73,
    
    /// Received 73, now sending 73 repeatedly (up to 5 times)
    /// Stops early if we hear partner calling CQ
    Sending73,
    
    /// QSO successfully completed
    Done,
}

impl std::fmt::Display for QsoState {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QsoState::Idle => write!(f, "IDLE"),
            QsoState::Listening => write!(f, "LISTEN"),
            QsoState::CallingCq => write!(f, "CALLING_CQ"),
            QsoState::CallingStn => write!(f, "CALLING_STN"),
            QsoState::WaitingRReport => write!(f, "WAIT_RRPT"),
            QsoState::WaitingRr => write!(f, "WAIT_RR"),
            QsoState::Waiting73 => write!(f, "WAIT_73"),
            QsoState::Sending73 => write!(f, "SEND_73"),
            QsoState::Done => write!(f, "DONE"),
        }
    }
}

/// User/UI intents that drive state changes
#[derive(Debug, Clone)]
pub enum Intent {
    /// Start listening for calls
    Listen,
    
    /// Start calling CQ
    Cq,
    
    /// Call a specific station
    Call { their: String },
    
    /// Answer a CQ (we heard CQ, now call them with report)
    AnswerCq { their: String, rpt: i16 },
    
    /// Send report (Format-1: "TO de FROM RPT")
    SendReport { rpt: i16 },
    
    /// Send R-report (Format-2: "R27")
    SendRReport { rpt: i16 },
    
    /// Send RR (Format-2)
    SendRr,
    
    /// Send 73 (Format-2)
    Send73,
    
    /// Abort current QSO
    Abort,
}

/// Events emitted by the engine
#[derive(Debug, Clone)]
pub enum EngineEvent {
    /// State changed
    StateChanged(QsoState),
    
    /// Message received
    Rx(RxEnvelope),
    
    /// Message being transmitted
    Tx(TxEnvelope),
    
    /// Informational message for UI
    Info(String),
    
    /// QSO completed successfully
    QsoComplete { their: String },
    
    /// Their callsign changed (for UI updates)
    TheirCallChanged { callsign: String },
}

/// Action to take after processing
#[derive(Debug, Clone)]
pub enum Action {
    /// No action needed
    None,
    
    /// Transmit this message
    Transmit(TxEnvelope),
}

/// The QSO state machine engine
pub struct QsoEngine {
    /// Our callsign
    pub my_call: String,
    
    /// Their callsign (current QSO partner)
    pub their_call: Option<String>,
    
    /// Current state
    pub state: QsoState,
    
    /// Our report to send (default 27)
    pub my_report: i16,
    
    /// Their report (received)
    pub their_report: Option<i16>,
    
    /// Were we the CQ caller? (affects who sends final 73)
    pub initiated_cq: bool,
    
    /// Should I send R-report in WaitingRr state?
    /// True = I received both calls + report (so I send R-report)
    /// False = I received R-report (so I send RR)
    pub i_send_rreport: bool,
    
    /// Last received message
    pub last_rx: Option<RxEnvelope>,
    
    /// Last transmitted message
    pub last_tx: Option<TxEnvelope>,
    
    /// Counter for repeated transmissions (e.g., multiple 73s)
    pub tx_repeat_count: u8,
    
    /// Maximum repeats before giving up
    pub max_repeats: u8,
}

impl QsoEngine {
    pub fn new(my_call: String) -> Self {
        Self {
            my_call,
            their_call: None,
            state: QsoState::Idle,
            my_report: 27,
            their_report: None,
            initiated_cq: false,
            i_send_rreport: false,
            last_rx: None,
            last_tx: None,
            tx_repeat_count: 0,
            max_repeats: 7,
        }
    }

    pub fn set_my_call(&mut self, my: String) {
        self.my_call = my;
    }

    pub fn set_their_call(&mut self, their: Option<String>) {
        self.their_call = their;
    }
    
    pub fn set_my_report(&mut self, rpt: i16) {
        self.my_report = rpt;
    }

    /// Process a user intent and return action + events
    pub fn on_intent(&mut self, intent: Intent) -> (Action, Vec<EngineEvent>) {
        let mut ev = vec![];
        let mut action = Action::None;

        match intent {
            Intent::Listen => {
                self.reset_qso();
                self.transition(QsoState::Listening, &mut ev);
            }
            
            Intent::Abort => {
                self.reset_qso();
                self.transition(QsoState::Idle, &mut ev);
            }
            
            Intent::Cq => {
                self.reset_qso();
                self.initiated_cq = true;
                
                let payload = Payload::Cq {
                    from: self.my_call.clone(),
                    qtf_deg: None,
                    period: None,
                };
                action = Action::Transmit(self.make_tx(payload, &mut ev));
                self.transition(QsoState::CallingCq, &mut ev);
            }
            
            Intent::Call { their } => {
                self.reset_qso();
                self.their_call = Some(their.clone());
                self.initiated_cq = true;  // Cold caller IS the initiator
                
                ev.push(EngineEvent::TheirCallChanged { callsign: their.clone() });
                
                // Cold call: "THEIR de MY" (no report yet)
                let payload = Payload::Call {
                    from: self.my_call.clone(),
                    to: their,
                };
                action = Action::Transmit(self.make_tx(payload, &mut ev));
                self.transition(QsoState::CallingStn, &mut ev);
            }
            
            Intent::AnswerCq { their, rpt } => {
                self.reset_qso();
                self.their_call = Some(their.clone());
                self.my_report = rpt;
                self.initiated_cq = false;
                self.i_send_rreport = false;  // I'm sending report, they will send R-report
                
                ev.push(EngineEvent::TheirCallChanged { callsign: their.clone() });
                
                // Answer CQ: "THEIR de MY RPT" (Format-1)
                let payload = Payload::CallWithReport {
                    from: self.my_call.clone(),
                    to: their,
                    rpt,
                };
                action = Action::Transmit(self.make_tx(payload, &mut ev));
                self.transition(QsoState::WaitingRReport, &mut ev);
            }
            
            Intent::SendReport { rpt } => {
                let Some(their) = self.their_call.clone() else {
                    ev.push(EngineEvent::Info("No target callsign set".to_string()));
                    return (Action::None, ev);
                };
                
                self.my_report = rpt;
                
                // Format-1 report: "THEIR de MY RPT"
                let payload = Payload::CallWithReport {
                    from: self.my_call.clone(),
                    to: their,
                    rpt,
                };
                action = Action::Transmit(self.make_tx(payload, &mut ev));
                self.transition(QsoState::WaitingRReport, &mut ev);
            }
            
            Intent::SendRReport { rpt } => {
                let Some(their) = self.their_call.clone() else {
                    ev.push(EngineEvent::Info("No target callsign set".to_string()));
                    return (Action::None, ev);
                };
                
                // Format-2 R-report: "R27"
                let payload = Payload::RReport {
                    from: self.my_call.clone(),
                    to: their,
                    rpt,
                };
                action = Action::Transmit(self.make_tx(payload, &mut ev));
                self.transition(QsoState::WaitingRr, &mut ev);
            }
            
            Intent::SendRr => {
                let Some(their) = self.their_call.clone() else {
                    ev.push(EngineEvent::Info("No target callsign set".to_string()));
                    return (Action::None, ev);
                };
                
                let payload = Payload::Rr {
                    from: self.my_call.clone(),
                    to: their,
                };
                action = Action::Transmit(self.make_tx(payload, &mut ev));
                self.transition(QsoState::Waiting73, &mut ev);
            }
            
            Intent::Send73 => {
                let Some(their) = self.their_call.clone() else {
                    ev.push(EngineEvent::Info("No target callsign set".to_string()));
                    return (Action::None, ev);
                };
                
                let payload = Payload::SeventyThree {
                    from: self.my_call.clone(),
                    to: their.clone(),
                };
                action = Action::Transmit(self.make_tx(payload, &mut ev));
                
                self.tx_repeat_count += 1;
                
                if self.tx_repeat_count >= self.max_repeats {
                    // Gave up waiting, consider QSO done anyway
                    self.transition(QsoState::Done, &mut ev);
                    ev.push(EngineEvent::QsoComplete { their });
                }
            }
        }

        (action, ev)
    }

    /// Process a received message and return action + events
    /// 
    /// This is where the Region-1 ladder logic lives.
    /// We check what state we're in and what we received, then advance.
    pub fn on_rx(&mut self, rx: RxEnvelope) -> (Action, Vec<EngineEvent>) {
        let mut ev = vec![EngineEvent::Rx(rx.clone())];
        self.last_rx = Some(rx.clone());

        let from_call = rx.payload.from_call().to_string();
        let to_call = rx.payload.to_call().map(|s| s.to_string());
        
        // Is this message addressed to us? (kept for clarity, guards check directly)
        let _is_for_us = to_call
            .as_ref()
            .map(|to| self.is_me(to))
            .unwrap_or(false);
        
        // Is this from our current QSO partner?
        let is_from_partner = self.their_call
            .as_ref()
            .map(|their| normalize_call(&from_call) == normalize_call(their))
            .unwrap_or(false);

        match (&self.state, &rx.payload) {
            // =========================================================
            // IDLE / LISTENING: React to incoming calls
            // =========================================================
            
            (QsoState::Idle | QsoState::Listening, Payload::Cq { from, .. }) => {
                // Heard CQ - inform UI but don't auto-answer
                ev.push(EngineEvent::Info(format!("Heard CQ from {}", from)));
            }
            
            (QsoState::Idle | QsoState::Listening, Payload::Call { from, to }) 
                if self.is_me(to) => 
            {
                // Someone calling us without report - capture them
                self.their_call = Some(from.clone());
                ev.push(EngineEvent::TheirCallChanged { callsign: from.clone() });
                ev.push(EngineEvent::Info(format!("{} calling us", from)));
            }
            
            (QsoState::Idle | QsoState::Listening, Payload::CallWithReport { from, to, rpt }) 
                if self.is_me(to) =>
            {
                // Someone calling us with report
                // I received both calls + report → I send R-report
                self.their_call = Some(from.clone());
                self.their_report = Some(*rpt);
                self.i_send_rreport = true;
                
                ev.push(EngineEvent::TheirCallChanged { callsign: from.clone() });
                ev.push(EngineEvent::Info(format!("{} calling us with report {} - sending R-report", from, rpt)));
                
                // Transition to WaitingRr - I will send R-report
                self.transition(QsoState::WaitingRr, &mut ev);
            }
            
            // =========================================================
            // CALLING CQ: Waiting for someone to answer
            // =========================================================
            
            (QsoState::CallingCq, Payload::CallWithReport { from, to, rpt }) 
                if self.is_me(to) =>
            {
                // Someone answered our CQ with a report!
                // I received both calls + report → I send R-report
                self.their_call = Some(from.clone());
                self.their_report = Some(*rpt);
                self.tx_repeat_count = 0;
                self.i_send_rreport = true;
                
                ev.push(EngineEvent::TheirCallChanged { callsign: from.clone() });
                ev.push(EngineEvent::Info(format!("{} answered CQ with report {}", from, rpt)));
                
                // Transition to WaitingRr - I will send R-report
                self.transition(QsoState::WaitingRr, &mut ev);
            }
            
            (QsoState::CallingCq, Payload::Call { from, to }) 
                if self.is_me(to) =>
            {
                // Someone answered our CQ without report
                self.their_call = Some(from.clone());
                self.tx_repeat_count = 0;
                
                ev.push(EngineEvent::TheirCallChanged { callsign: from.clone() });
                ev.push(EngineEvent::Info(format!("{} answered CQ (no report)", from)));
            }
            
            // =========================================================
            // CALLING STATION: Waiting for their response
            // =========================================================
            
            (QsoState::CallingStn, Payload::CallWithReport { from, to, rpt })
                if self.is_me(to) && is_from_partner =>
            {
                // They responded with report
                // I received both calls + report → I send R-report
                self.their_report = Some(*rpt);
                self.tx_repeat_count = 0;
                self.i_send_rreport = true;
                
                ev.push(EngineEvent::Info(format!("Received report {} from {}", rpt, from)));
                self.transition(QsoState::WaitingRr, &mut ev);
            }
            
            // =========================================================
            // WAITING FOR R-REPORT: We sent our report, waiting for R27
            // =========================================================
            
            (QsoState::WaitingRReport, Payload::RReport { from, to, rpt })
                if self.is_me(to) && is_from_partner =>
            {
                // Received R-report (Format-2) - I will send RR
                self.their_report = Some(*rpt);
                self.tx_repeat_count = 0;
                self.i_send_rreport = false;  // I received R-report, so I send RR
                
                ev.push(EngineEvent::Info(format!("Received R{} from {}", rpt, from)));
                self.transition(QsoState::WaitingRr, &mut ev);
            }
            
            (QsoState::WaitingRReport, Payload::CallWithReport { from, to, rpt })
                if self.is_me(to) && is_from_partner =>
            {
                // They're repeating their Format-1 - they haven't received our report yet
                // Stay in state, keep sending our report
                self.their_report = Some(*rpt);
                ev.push(EngineEvent::Info(format!("Received repeat report {} from {}", rpt, from)));
            }
            
            // =========================================================
            // WAITING FOR RR: We sent R-report, waiting for RR
            // =========================================================
            
            (QsoState::WaitingRr, Payload::Rr { from, to })
                if self.is_me(to) && is_from_partner =>
            {
                // Received RR
                self.tx_repeat_count = 0;
                ev.push(EngineEvent::Info(format!("Received RR from {}", from)));
                self.transition(QsoState::Waiting73, &mut ev);
            }
            
            (QsoState::WaitingRr, Payload::RReport { from, to, .. })
                if self.is_me(to) && is_from_partner =>
            {
                // They're repeating R-report - they didn't get ours
                ev.push(EngineEvent::Info(format!("Received repeat R-report from {}", from)));
            }
            
            (QsoState::WaitingRr, Payload::SeventyThree { from, to })
                if self.is_me(to) && is_from_partner =>
            {
                // Received 73 - now send 73 back for 5 periods
                self.tx_repeat_count = 0;
                ev.push(EngineEvent::Info(format!("Received 73 from {} - sending 73s", from)));
                self.transition(QsoState::Sending73, &mut ev);
            }
            
            // =========================================================
            // WAITING FOR 73: We sent RR, waiting for 73
            // =========================================================
            
            (QsoState::Waiting73, Payload::SeventyThree { from, to })
                if self.is_me(to) && is_from_partner =>
            {
                // Received 73 - now send 73 back for 5 periods
                self.tx_repeat_count = 0;
                ev.push(EngineEvent::Info(format!("Received 73 from {} - sending 73s", from)));
                self.transition(QsoState::Sending73, &mut ev);
            }
            
            (QsoState::Waiting73, Payload::Rr { from, to })
                if self.is_me(to) && is_from_partner =>
            {
                // They're repeating RR - they didn't get our RR/73
                ev.push(EngineEvent::Info(format!("Received repeat RR from {}", from)));
            }
            
            // =========================================================
            // SENDING 73: We're sending 73 repeatedly after receiving their 73
            // =========================================================
            
            (QsoState::Sending73, Payload::SeventyThree { from, to })
                if self.is_me(to) && is_from_partner =>
            {
                // We're sending 73 and received 73 back - QSO complete!
                ev.push(EngineEvent::Info(format!("Received 73 from {} - QSO complete", from)));
                let their = self.their_call.clone().unwrap_or_default();
                self.transition(QsoState::Done, &mut ev);
                ev.push(EngineEvent::QsoComplete { their });
            }
            
            (QsoState::Sending73, Payload::Cq { from, .. })
                if is_from_partner =>
            {
                // Partner started calling CQ again - they're done, so we're done!
                ev.push(EngineEvent::Info(format!("{} calling CQ - QSO complete", from)));
                let their = self.their_call.clone().unwrap_or_default();
                self.transition(QsoState::Done, &mut ev);
                ev.push(EngineEvent::QsoComplete { their });
            }
            
            // =========================================================
            // DONE: QSO finished, but might receive final 73
            // =========================================================
            
            (QsoState::Done, Payload::SeventyThree { from, to })
                if self.is_me(to) && is_from_partner =>
            {
                // Final 73 confirmation
                ev.push(EngineEvent::Info(format!("Received final 73 from {}", from)));
            }
            
            // =========================================================
            // DEFAULT: Log but don't act
            // =========================================================
            _ => {
                log::debug!(
                    "QSO: Ignoring message in state {:?}: {:?}",
                    self.state,
                    rx.payload
                );
            }
        }

        (Action::None, ev)
    }
    
    /// Get the next message to transmit based on current state.
    /// This is used for auto-sequencing in the runtime.
    pub fn next_tx(&self) -> Option<Payload> {
        match self.state {
            QsoState::CallingCq => {
                // CQ doesn't need their_call
                Some(Payload::Cq {
                    from: self.my_call.clone(),
                    qtf_deg: None,
                    period: None,
                })
            }
            
            QsoState::CallingStn => {
                let their = self.their_call.as_ref()?;
                Some(Payload::Call {
                    from: self.my_call.clone(),
                    to: their.clone(),
                })
            }
            
            QsoState::WaitingRReport => {
                let their = self.their_call.as_ref()?;
                // We need to send our report (Format-1)
                Some(Payload::CallWithReport {
                    from: self.my_call.clone(),
                    to: their.clone(),
                    rpt: self.my_report,
                })
            }
            
            QsoState::WaitingRr => {
                let their = self.their_call.as_ref()?;
                if self.i_send_rreport {
                    // I received both calls + report → send R-report (Format-2)
                    Some(Payload::RReport {
                        from: self.my_call.clone(),
                        to: their.clone(),
                        rpt: self.my_report,
                    })
                } else {
                    // I received R-report → send RR
                    Some(Payload::Rr {
                        from: self.my_call.clone(),
                        to: their.clone(),
                    })
                }
            }
            
            QsoState::Waiting73 => {
                let their = self.their_call.as_ref()?;
                // Send 73
                Some(Payload::SeventyThree {
                    from: self.my_call.clone(),
                    to: their.clone(),
                })
            }
            
            QsoState::Sending73 => {
                let their = self.their_call.as_ref()?;
                // Send 73 repeatedly (up to 5 times or until they call CQ)
                Some(Payload::SeventyThree {
                    from: self.my_call.clone(),
                    to: their.clone(),
                })
            }
            
            QsoState::Done => {
                let their = self.their_call.as_ref()?;
                // Send 73 if needed
                Some(Payload::SeventyThree {
                    from: self.my_call.clone(),
                    to: their.clone(),
                })
            }
            
            _ => None,
        }
    }

    fn is_me(&self, call: &str) -> bool {
        normalize_call(call) == normalize_call(&self.my_call)
    }

    fn transition(&mut self, next: QsoState, ev: &mut Vec<EngineEvent>) {
        if self.state != next {
            log::info!("QSO: {:?} -> {:?}", self.state, next);
            self.state = next;
            ev.push(EngineEvent::StateChanged(next));
        }
    }

    fn make_tx(&mut self, payload: Payload, ev: &mut Vec<EngineEvent>) -> TxEnvelope {
        let format = payload.format();
        let raw = render_payload(&payload);
        let tx = TxEnvelope { payload, format, raw };
        self.last_tx = Some(tx.clone());
        ev.push(EngineEvent::Tx(tx.clone()));
        tx
    }
    
    fn reset_qso(&mut self) {
        self.their_call = None;
        self.their_report = None;
        self.initiated_cq = false;
        self.i_send_rreport = false;
        self.tx_repeat_count = 0;
    }
}

fn normalize_call(s: &str) -> String {
    s.trim().to_uppercase()
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_cq_workflow() {
        let mut engine = QsoEngine::new("GW4WND".into());
        
        // Start CQ
        let (action, _events) = engine.on_intent(Intent::Cq);
        
        assert!(matches!(action, Action::Transmit(_)));
        assert_eq!(engine.state, QsoState::CallingCq);
        assert!(engine.initiated_cq);
    }
    
    #[test]
    fn test_answer_cq_workflow() {
        let mut engine = QsoEngine::new("GW4WND".into());
        
        // Answer someone's CQ
        let (action, _events) = engine.on_intent(Intent::AnswerCq { 
            their: "SM2CEW".into(), 
            rpt: 27 
        });
        
        assert!(matches!(action, Action::Transmit(_)));
        assert_eq!(engine.state, QsoState::WaitingRReport);
        assert_eq!(engine.their_call, Some("SM2CEW".into()));
        assert!(!engine.initiated_cq);
    }
    
    #[test]
    fn test_receive_rreport() {
        let mut engine = QsoEngine::new("GW4WND".into());
        engine.their_call = Some("SM2CEW".into());
        engine.state = QsoState::WaitingRReport;
        
        // Receive R-report
        let rx = RxEnvelope {
            payload: Payload::RReport {
                from: "SM2CEW".into(),
                to: "GW4WND".into(),
                rpt: 27,
            },
            format: Format::Fmt2,
            snr: None,
            utc_ms: 0,
            rx_slot: 0,
        };
        
        let (_action, _events) = engine.on_rx(rx);
        
        assert_eq!(engine.state, QsoState::WaitingRr);
        assert_eq!(engine.their_report, Some(27));
    }
    
    #[test]
    fn test_full_qso_as_cq_caller() {
        let mut engine = QsoEngine::new("GW4WND".into());
        
        // 1. Start CQ
        let _ = engine.on_intent(Intent::Cq);
        assert_eq!(engine.state, QsoState::CallingCq);
        
        // 2. Receive answer: "GW4WND de SM2CEW 27"
        let rx = RxEnvelope {
            payload: Payload::CallWithReport {
                from: "SM2CEW".into(),
                to: "GW4WND".into(),
                rpt: 27,
            },
            format: Format::Fmt1,
            snr: None,
            utc_ms: 0,
            rx_slot: 1,
        };
        let _ = engine.on_rx(rx);
        assert_eq!(engine.state, QsoState::WaitingRReport);
        assert_eq!(engine.their_call, Some("SM2CEW".into()));
        
        // 3. Send our report (triggered by UI)
        let _ = engine.on_intent(Intent::SendReport { rpt: 27 });
        assert_eq!(engine.state, QsoState::WaitingRReport);
        
        // 4. Receive R-report
        let rx = RxEnvelope {
            payload: Payload::RReport {
                from: "SM2CEW".into(),
                to: "GW4WND".into(),
                rpt: 27,
            },
            format: Format::Fmt2,
            snr: None,
            utc_ms: 0,
            rx_slot: 1,
        };
        let _ = engine.on_rx(rx);
        assert_eq!(engine.state, QsoState::WaitingRr);
        
        // 5. Send RR
        let _ = engine.on_intent(Intent::SendRr);
        assert_eq!(engine.state, QsoState::Waiting73);
        
        // 6. Receive 73
        let rx = RxEnvelope {
            payload: Payload::SeventyThree {
                from: "SM2CEW".into(),
                to: "GW4WND".into(),
            },
            format: Format::Fmt2,
            snr: None,
            utc_ms: 0,
            rx_slot: 1,
        };
        let (_, events) = engine.on_rx(rx);
        assert_eq!(engine.state, QsoState::Done);
        
        // Check for QsoComplete event
        let complete = events.iter().find(|e| matches!(e, EngineEvent::QsoComplete { .. }));
        assert!(complete.is_some());
    }
}
